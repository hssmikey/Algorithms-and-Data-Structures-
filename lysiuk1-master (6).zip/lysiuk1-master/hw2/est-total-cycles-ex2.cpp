#include <iostream>
using namespace std;

int main() 
{
  int i, x;

    for (i=0; i<200; i++)
      x=i; //in Assembly code I got confused by salL function in .L3 memory portion. It appears to be a shift instruction like >> or <<. I tried it out however it did not work because then the whole memory allocation of .L3 and .L2 changes. Therefore I left this version because it is the closest.




  return 0;
}
