#include <iostream>
using namespace std;

int main() 
{
  int i, x;

    for (i=0; i<500; i++)
      x = i;

     cout << i << endl;



  return 0;
}
