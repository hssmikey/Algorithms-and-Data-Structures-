#include <iostream>
using namespace std;
int main(){

  int count=1;
  for (count=1; count <=10; count ++)
    cout <<count<<endl;

  return 0;
}
 
