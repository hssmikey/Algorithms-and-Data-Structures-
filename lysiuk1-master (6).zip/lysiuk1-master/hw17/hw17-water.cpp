//Project by Misha, Thabiso, David

#include <iostream>
using namespace std;


//visited global array and move declaration
bool visited[4][7][10];
int* move(int a, int b, int size);



// explore recur function
void explore(int a, int b, int c) {

  static unsigned int t= 0;
t++;
    //test if a=2 or b=2
    if (a==2 || b==2) {
        cout << "Solution found: " << a << " " << b << " " << c << endl;
	cout <<"Number of moves:"<< t << endl; 
        return;
    }

    // travel node
    visited[a][b][c] = true;

    
    int* new_v;
    //travel edges
    new_v = move(a,b,7);
    if (visited[new_v[0]][new_v[1]][c] == false) {
        explore(new_v[0], new_v[1], c);
    }
    delete [] new_v;

    new_v = move(b,c,10);
    if (visited[a][new_v[0]][new_v[1]] == false) {
        explore(a, new_v[0], new_v[1]);
    }
    delete [] new_v;

    new_v = move(a,c,10);
    if (visited[new_v[0]][b][new_v[1]] == false) {
        explore(new_v[0], b, new_v[1]);
    }
    delete [] new_v;

    new_v = move(b,a,4);
    if (visited[new_v[1]][new_v[0]][c] == false) {
        explore(new_v[1], new_v[0], c);
    }
    delete [] new_v;

    new_v = move(c,a,4);
    if (visited[new_v[1]][b][new_v[0]] == false) {
        explore(new_v[1], b, new_v[0]);
    }
    delete [] new_v;

    new_v = move(c,b,7);
    if (visited[a][new_v[1]][new_v[0]] == false) {
        explore(a, new_v[1], new_v[0]);
    }
    delete [] new_v;

}


//move function
int* move(int x, int y, int size) {
    int diff = size - y;
    if (x <= diff) {
        y += x;
        x = 0;
    } else {
        y += diff;
        x -= diff;
    }
    int* r = new int[2];
    r[0] = x;
    r[1] = y;
    return r;
}




//main function
int main() {
    int a,b,c;
    a = 4;
    b = 7;
    c = 0;

    //visited array
    //bool visited[4][7][10];
    for (int i=0; i<4; i++)
        for (int j=0; j<7; j++)
            for (int k=0; k<10; k++)
                visited[i][j][k] = false;

    //call explore function
    explore(a,b,c);
    
    //cout << move(a,b,7) << endl;
    //int* test = move(a,b,7);
    
    return 0;
}
