//Misha, Thabiso, David


#include <iostream>
using namespace std;


// heapify function
void heapify(int* arr, int len, int index) {
    int parent = index;
    int child1 = (2*parent) + 1;
    int child2 = (2*parent) + 2;
    int next_parent;
    while (child1 < len) {
        next_parent = child1;
        if (child2 < len) { 
            if (arr[child2] > arr[child1]) { 
                if (arr[child2] > arr[parent]) {
                    int temp = arr[parent];
                    arr[parent] = arr[child2];
                    arr[child2] = temp;
                    next_parent = child2;
                }
            } else { 
                if (arr[child1] > arr[parent]) {
                    int temp = arr[parent];
                    arr[parent] = arr[child1];
                    arr[child1] = temp;
                    next_parent = child1;
                }
            }
        } else {
            if (arr[child1] > arr[parent]) {
                    int temp = arr[parent];
                    arr[parent] = arr[child1];
                    arr[child1] = temp;
                    next_parent = child1;
            }
        }
        //change index of children
        parent = next_parent;
        child1 = 2*parent +1;
        child2 = 2*parent +2;
    }

}


//1st step of sorting heap
void sort_heap(int* arr, int len) {
    // heapified
    for (int i=len-1; i>=0; i--) {
        heapify(arr, len, i);
    }

    // sort the sorted heap
    for (int i=len-1; i>0; i--) {
        int temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;
        heapify(arr, --len, 0);
    }

}





int main () {
    //create heap
    int heap[] = {1,2,3,4,10,9,8,7,6,5,20,19,15,23};
    
    //sort heap
    sort_heap(heap, 14);

    //print out array
    for (int i=0; i<14; i++)
        cout << heap[i] << endl;





    return 0;
}
