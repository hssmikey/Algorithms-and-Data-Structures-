#include <iostream>
using namespace std;
#include"elapsed_time.h"




int main() 
{
start_timer(); 

 int x = 0;

  for ( int i = 0; i < 100; ++i ) {
  for ( int j = 0; j < i; ++j ) {
    for ( int k = 0; k < j; ++k ) {
      x = x + 5;
    }
  }
}


 double cycles = elapsed_time();
 

cout << " Total cycles: " << cycles << endl;

  return 0;
}

