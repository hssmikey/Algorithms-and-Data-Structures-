#include <iostream>
using namespace std;
#include"elapsed_time.h"

void recursion(int n)
{
  double x = 2 * 3;
  x = x * 3;
 
  if (n > 0) {
    recursion(n-1);
    recursion(n-1);
  }
}




int main() 
{
start_timer(); 
  recursion(100);

 double cycles = elapsed_time();
 

cout << " Total cycles: " << cycles << endl;

  return 0;
}

