#include <iostream>
using namespace std;

#include"elapsed_time.h"

int main() 
{

start_timer();
  int i;
 for ( int i = 0; i <= 100; ++i ) {
  for ( int j = 0; j <= i/2; ++j ) {
    i = i + 2;
  }
};

double cycles = elapsed_time(); 

  cout << " Total cycles: " << cycles << endl;


  return 0;
}
